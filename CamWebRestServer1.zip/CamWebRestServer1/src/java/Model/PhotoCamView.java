/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.File;
import java.io.IOException;
import javax.faces.FacesException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.imageio.stream.FileImageOutputStream;
import org.primefaces.event.CaptureEvent;

/**
 *
 * @author necati
 */
@ManagedBean
@ViewScoped
public class PhotoCamView {
    String filename; 
    String getRandomImageName() 
    {
        int i = (int) (Math.random() * 10000000);
                return String.valueOf(i); 
    }
    public String getFilename()
    {
        return filename;
    }
    
    public void oncapture(CaptureEvent captureEvent)
    {
        filename = getRandomImageName();
        byte[] data = captureEvent.getData();
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        String newFileName = externalContext.getRealPath("") + File.separator + "resources" + File.separator + "demo" + File.separator+ "images" + File.separator + "photocam" + File.separator + filename+ ".jpeg";
        FileImageOutputStream imageOutpur; 
        try
        {
            imageOutpur = new FileImageOutputStream(new File(newFileName));
            imageOutpur.write(data, 0, data.length);
            imageOutpur.close();
        } catch (IOException e)
        {
            throw new FacesException("Fehler", e);
        }
}
}
